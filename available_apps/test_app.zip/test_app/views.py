from django.http import HttpResponse


def index(req):
    return HttpResponse("Successfully installed", content_type='text/plain')
